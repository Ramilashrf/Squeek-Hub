(() => {
  'use strict';
  const endpoint = 'https://api.squeekchain.com/v1/status';
  const themes = {violet:'#c3aaff', mint:'#8bf3c3', amber:'#ffc279', ice:'#9cdfff'};
  const presets = {
    retro:{theme:'amber',layout:'card',metrics:true,solid:true},
    minimal:{theme:'ice',layout:'compact',metrics:false,solid:false},
    neon:{theme:'mint',layout:'card',metrics:true,solid:false}
  };
  const defaults = {preset:'classic',title:'Squeektoshi Live', theme:'violet', layout:'card', metrics:true, solid:false, surge:false, surgeRpm:50};
  const storageKey = 'squeek-studio-settings-v1';
  const params = new URLSearchParams(location.search);
  const embedded = document.documentElement.dataset.config;
  const overlay = Boolean(embedded) || document.documentElement.dataset.mode === 'overlay';
  const studio = document.getElementById('studio');
  const template = document.getElementById('overlay-template');
  const widget = template.content.firstElementChild.cloneNode(true);
  const target = overlay ? document.body : document.getElementById('stage');
  target.append(widget);
  if (overlay) { document.documentElement.dataset.mode = 'overlay'; studio?.remove(); }
  const find = (selector) => widget.querySelector(selector);
  const status = document.getElementById('preview-status');
  const format = new Intl.NumberFormat('en-US');
  const rpmFormat = new Intl.NumberFormat('en-US', {maximumFractionDigits:1});
  let sample = false;
  let lastReading = null;
  let recording = null;
  let replayActive = false;
  let replayStarted = 0;
  const runId = params.get('run');
  const replayButton = document.getElementById('replay');
  let replayTimer;
  function startReplay() {
    clearInterval(replayTimer);
    replayStarted = performance.now();
    replayActive = true;
    sample = false;
    document.getElementById('live')?.setAttribute('aria-pressed','false');
    document.getElementById('sample')?.setAttribute('aria-pressed','false');
    replayButton?.setAttribute('aria-pressed','true');
    renderFeed();
    replayTimer = setInterval(renderFeed, 150);
  }
  function stopReplay() {
    replayActive = false;
    clearInterval(replayTimer);
    replayButton?.setAttribute('aria-pressed','false');
    if (runId) {
      const url = new URL(location.href);
      url.searchParams.delete('run');
      history.replaceState(null,'',url);
    }
  }
  function replayReading() {
    const elapsed = performance.now() - replayStarted;
    const times = recording.offsets;
    const finished = elapsed >= times.at(-1) + 1000;
    const count = times.filter(time => time <= elapsed).length;
    const current = times[count - 1];
    const previous = times[count - 2];
    const gap = current - previous;
    const rpm = !finished && gap > 0 && elapsed - current < Math.max(gap * 1.6, 1000) ? 60000 / gap : 0;
    if (finished) clearInterval(replayTimer);
    return {kind:'replay', label:'RUN REPLAY', detail:finished ? 'Replay complete' : 'Recorded wheel activity', rpm, work:null, blocks:null};
  }
  async function loadReplay() {
    const embeddedReplay = document.documentElement.dataset.replay;
    if (!runId && !embeddedReplay) return;
    try {
      if (embeddedReplay) recording = JSON.parse(embeddedReplay);
      else {
        const response = await fetch('./runs.json', {signal:AbortSignal.timeout(8000)});
        if (!response.ok) throw new Error('Run archive unavailable');
        recording = (await response.json()).find(run => run.id === runId);
      }
      if (!recording?.offsets?.length) throw new Error('Run not found');
      if (replayButton) {
        replayButton.hidden = false;
        replayButton.addEventListener('click', startReplay);
      }
      startReplay();
    } catch {
      display({kind:'warning', label:'NO REPLAY', detail:'Recorded run unavailable'});
    }
  }

  function normalize(raw = {}) {
    return {
      title: typeof raw.title === 'string' ? raw.title.trim().slice(0,42) || defaults.title : defaults.title,
      preset: Object.hasOwn(presets, raw.preset) ? raw.preset : defaults.preset,
      theme: Object.hasOwn(themes, raw.theme) ? raw.theme : defaults.theme,
      layout: raw.layout === 'compact' ? 'compact' : 'card',
      metrics: raw.metrics !== false,
      solid: raw.solid === true,
      surge: raw.surge === true,
      surgeRpm: Number.isInteger(raw.surgeRpm) && raw.surgeRpm >= 1 && raw.surgeRpm <= 300 ? raw.surgeRpm : defaults.surgeRpm
    };
  }

  function readSettings() {
    if (embedded) {
      try { return normalize(JSON.parse(embedded)); } catch { return {...defaults}; }
    }
    if (overlay) {
      return normalize({preset:params.get('preset'), title:params.get('title'), theme:params.get('theme'), layout:params.get('layout'),
        metrics:params.get('metrics') !== '0', solid:params.get('solid') === '1', surge:params.get('surge') === '1', surgeRpm:Number(params.get('surgeRpm'))});
    }
    try { return normalize(JSON.parse(localStorage.getItem(storageKey)) || {}); }
    catch { return {...defaults}; }
  }

  let settings = readSettings();

  function applySettings() {
    widget.style.setProperty('--accent', themes[settings.theme]);
    widget.dataset.preset = settings.preset;
    widget.dataset.layout = settings.layout;
    widget.dataset.solid = settings.solid;
    find('.widget-title').textContent = settings.title;
    find('.metric-row').hidden = !settings.metrics || replayActive;
    if (!overlay) {
      document.querySelectorAll('[data-preset-option]').forEach(button => {
        button.setAttribute('aria-pressed',String(button.dataset.presetOption === settings.preset));
      });
      document.querySelectorAll('[data-theme]').forEach(button => {
        button.setAttribute('aria-pressed', String(button.dataset.theme === settings.theme));
      });
    }
  }

  let surgeTimer;
  let aboveThreshold = false;
  function showSurge() {
    const banner = find('.surge-alert');
    banner.hidden = false;
    clearTimeout(surgeTimer);
    surgeTimer = setTimeout(() => { banner.hidden = true; },3200);
  }
  function display(reading) {
    const {kind, label, detail, rpm, work, blocks} = reading;
    const validFeed = kind === 'live' || replayActive;
    if (validFeed && Number.isFinite(rpm)) {
      const above = rpm >= settings.surgeRpm;
      if (settings.surge && above && !aboveThreshold) showSurge();
      aboveThreshold = above;
    }
    widget.dataset.feed = kind;
    find('.metric-row').hidden = !settings.metrics || replayActive;
    find('.feed-label').textContent = label;
    find('.state').textContent = detail;
    find('.rpm').textContent = rpm == null ? '—' : rpmFormat.format(rpm);
    find('.work').textContent = work ?? '—';
    find('.blocks').textContent = blocks ?? '—';
    widget.dataset.moving = String(rpm > 0);
    if (rpm > 0) widget.style.setProperty('--spin', Math.max(.2, 60 / rpm) + 's');
    if (status) status.textContent = kind === 'sample' ? 'Simulated preview' : detail;
  }

  function integer(value) {
    return typeof value === 'string' && /^\d{1,30}$/.test(value) ? format.format(BigInt(value)) : null;
  }

  function interpret(data) {
    const m = data?.measurement;
    const unknown = {kind:'warning', label:'NO FEED', detail:'Waiting for a wheel reading'};
    if (!m || data.status === 'unavailable') return unknown;
    const received = Date.parse(m.receivedAt);
    const observed = Date.parse(m.observedAt);
    const maxAge = Number.isFinite(m.staleAfterSeconds) && m.staleAfterSeconds > 0 ? m.staleAfterSeconds : 120;
    if (m.freshness !== 'online' || !Number.isFinite(received) || !Number.isFinite(observed)
        || Date.now() - Math.min(received, observed) > maxAge * 1000) {
      return {kind:'warning', label:'STALE', detail:'Waiting for a fresh wheel reading'};
    }
    if (!Number.isSafeInteger(m.rpmMilli) || m.rpmMilli < 0 || !['ACTIVE','IDLE'].includes(m.coreStatus)) {
      return {kind:'warning', label:'NO FEED', detail:'Wheel reading unavailable'};
    }
    const isHardware = m.provenance === 'hardware';
    const source = {simulated:'SIMULATED', replay:'REPLAY', derived:'DERIVED'}[m.provenance];
    if (!isHardware && !source) return unknown;
    return {
      kind:isHardware ? 'live' : 'sample', label:isHardware ? 'LIVE DATA' : source,
      detail:m.rpmMilli > 0 ? 'Wheel turning' : 'Wheel idle', rpm:m.rpmMilli/1000,
      work:integer(m.cumulativeWorkUnits),
      blocks:data.builder?.status === 'available' ? integer(data.builder.projected?.blockHeight) : null
    };
  }

  function renderFeed() {
    if (replayActive) display(replayReading());
    else if (sample) {
      display({kind:'sample', label:'SAMPLE DATA', detail:'Wheel turning', rpm:37.4, work:'18,553', blocks:'1,999'});
    } else if (lastReading) display(lastReading);
    else display({kind:'warning',label:'CONNECTING',detail:'Connecting to Squeekchain…'});
  }

  async function poll() {
    let delay = 10000;
    try {
      const response = await fetch(endpoint, {credentials:'omit', signal:AbortSignal.timeout(8000)});
      if (!response.ok) {
        const retry = Number(response.headers.get('Retry-After'));
        if (Number.isFinite(retry) && retry > 0) delay = Math.max(delay, retry * 1000);
        throw new Error('Status unavailable');
      }
      lastReading = interpret(await response.json());
    } catch {
      lastReading = {kind:'warning',label:'OFFLINE',detail:'Feed unavailable · retrying'};
    }
    renderFeed();
    setTimeout(poll,delay);
  }

  if (!overlay) {
    const title = document.getElementById('title-input');
    const layout = document.getElementById('layout');
    const metrics = document.getElementById('metrics');
    const solid = document.getElementById('solid');
    const live = document.getElementById('live');
    const sampleButton = document.getElementById('sample');
    const actionStatus = document.getElementById('action-status');
    function message(value) {
      actionStatus.hidden = !value;
      actionStatus.textContent = value;
    }
    function update(change) {
      settings = normalize({...settings,...change});
      try { localStorage.setItem(storageKey, JSON.stringify(settings)); } catch {}
      message('');
      applySettings();
    }
    function fillControls() {
      title.value = settings.title;
      layout.value = settings.layout;
      metrics.checked = settings.metrics;
      solid.checked = settings.solid;
      document.getElementById('surge-enabled').checked = settings.surge;
      document.getElementById('surge-rpm').value = settings.surgeRpm;
    }
    function setSample(value) {
      stopReplay();
      sample = value;
      live.setAttribute('aria-pressed', String(!value));
      sampleButton.setAttribute('aria-pressed', String(value));
      renderFeed();
    }
    fillControls();
    title.addEventListener('input', () => update({title:title.value}));
    layout.addEventListener('change', () => update({layout:layout.value}));
    metrics.addEventListener('change', () => update({metrics:metrics.checked}));
    document.getElementById('surge-enabled').addEventListener('change',event => {
      aboveThreshold = false;
      update({surge:event.target.checked});
      if (!settings.surge) find('.surge-alert').hidden = true;
      renderFeed();
    });
    document.getElementById('surge-rpm').addEventListener('change',event => {
      aboveThreshold = false;
      update({surgeRpm:event.target.valueAsNumber});
      fillControls();
      renderFeed();
    });
    document.getElementById('surge-test').addEventListener('click',showSurge);
    solid.addEventListener('change', () => update({solid:solid.checked}));
    document.querySelectorAll('[data-theme]').forEach(button => button.addEventListener('click', () => update({theme:button.dataset.theme})));
    document.querySelectorAll('[data-preset-option]').forEach(button => button.addEventListener('click', () => {
      const preset = button.dataset.presetOption;
      update({preset,...presets[preset]});
      fillControls();
    }));
    document.getElementById('reset').addEventListener('click', () => { update(defaults); fillControls(); });
    live.addEventListener('click', () => setSample(false));
    sampleButton.addEventListener('click', () => {
      window.documentPictureInPicture?.window?.close();
      setSample(true);
    });

    const floatButton = document.getElementById('float-card');
    const standalone = document.getElementById('standalone-studio');
    const extension = location.protocol === 'chrome-extension:';
    if (extension) {
      document.querySelector('.mast nav').hidden = true;
      document.querySelector('.mast .brand').href = './studio.html';
      document.getElementById('extension-download').hidden = true;
      document.getElementById('extension-guide').hidden = true;
    }
    if (window.top !== window) {
      standalone.href = location.href;
      standalone.hidden = false;
    } else if (window.documentPictureInPicture) {
      floatButton.hidden = false;
    } else {
      message('Floating cards require a Chrome version with Document Picture-in-Picture.');
    }

    floatButton.addEventListener('click',async () => {
      const pip = window.documentPictureInPicture;
      if (pip.window) {
        pip.window.close();
        return;
      }
      floatButton.disabled = true;
      try {
        const popup = await pip.requestWindow({
          width: settings.layout === 'compact' ? 380 : 440,
          height: settings.layout === 'compact' ? 185 : 250
        });
        if (sample) setSample(false);
        const doc = popup.document;
        doc.title = 'Squeektoshi Live';
        doc.documentElement.dataset.mode = 'overlay';
        doc.head.append(document.querySelector('style').cloneNode(true));
        Object.assign(doc.body.style,{margin:'0',padding:'0',background:'#100e15',overflow:'auto'});
        Object.assign(widget.style,{maxWidth:'none',borderRadius:'0',minHeight:'100vh'});
        doc.body.append(widget);
        floatButton.textContent = 'Close floating card';
        message('The floating card is open. Keep this tab open while you browse.');
        popup.addEventListener('pagehide',() => {
          for (const prop of ['max-width','border-radius','min-height']) widget.style.removeProperty(prop);
          target.append(widget);
          floatButton.textContent = 'Open floating card';
          message('');
        },{once:true});
      } catch {
        message('Chrome could not open the floating card. Try again from this tab.');
      } finally {
        floatButton.disabled = false;
      }
    });
  }

  applySettings();
  renderFeed();
  if (embedded || overlay) document.getElementById('hub-css')?.remove();
  if (runId || document.documentElement.dataset.replay) loadReplay();
  if (!overlay || (!runId && !document.documentElement.dataset.replay)) poll();
})();
