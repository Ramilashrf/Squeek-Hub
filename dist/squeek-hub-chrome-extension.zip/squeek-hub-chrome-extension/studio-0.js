if (new URLSearchParams(location.search).get('mode') === 'overlay') document.documentElement.dataset.mode = 'overlay';
